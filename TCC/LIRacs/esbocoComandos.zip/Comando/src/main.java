
import java.io.IOException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Aluno
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        main.reiniciar();
    }
    
    public static void desligaComputador() throws IOException {
        Runtime runtime = Runtime.getRuntime();
	Process proc = runtime.exec("shutdown -s -m");
	System.exit(0);
    }
    
    public static void reiniciar() throws IOException {
        Runtime runtime = Runtime.getRuntime();
        Process proc = runtime.exec("shutdown -g");
        System.exit(0);
                
                
    }
    
}
