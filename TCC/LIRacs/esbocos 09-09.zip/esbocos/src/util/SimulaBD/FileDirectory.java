/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util.SimulaBD;

/**
 *
 * @author Nelore
 */
public class FileDirectory {

    private String raiz;
    private String filename;
    
    public FileDirectory() {
        this.raiz = null;
        this.filename = null;
    }
    
    public FileDirectory(String raiz, String name) {
        this.raiz = raiz;
        this.filename = name;
    }
    
    public String getFullDirectory() {
        return raiz+"/"+filename;
    }
    
    public String getRaiz() {
        return raiz;
    }

    public void setRaiz(String raiz) {
        this.raiz = raiz;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }
    
    
    
}
