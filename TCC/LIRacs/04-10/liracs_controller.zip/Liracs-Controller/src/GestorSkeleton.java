
import Liracs.controller.skeletons.SkeletonAutenticar;
import Liracs.controller.skeletons.SkeletonInserirUsuario;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Nelore
 */
public class GestorSkeleton implements Runnable{
    
    private Socket socket;
    private ObjectInputStream reader;
    private ObjectOutputStream writer;
    
    
    public GestorSkeleton(Socket socket) {
        this.socket = socket;
    }
    
    
    @Override
    public void run() {
        try {
            String aux ="aa";
            writer = new ObjectOutputStream(socket.getOutputStream());
            reader = new ObjectInputStream(socket.getInputStream());
            aux = reader.readUTF();
            switch (aux) {     //verifico a consistência de dados
                case "Autenticar usuario":
                    SkeletonAutenticar autenticar = new SkeletonAutenticar(this.socket, reader, writer);
                    autenticar.autenticar();
                    break;
                case "Cadastrar usuario":
                    SkeletonInserirUsuario inserirUser = new SkeletonInserirUsuario(this.socket, reader, writer);
                    inserirUser.inserirUsuario();
                    break;
                case "Listar comandos":
                    
                    
                default:
                    System.out.print("deu ruim");
            }
                    
            
        } catch (IOException ex) {
            Logger.getLogger(GestorSkeleton.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
