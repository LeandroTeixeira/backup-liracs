/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package liracs.model.DAO.impl;

import liracs.model.DAO.impl.interfaces.IUsuarioDAO;
import liracs.model.DAO.impl.interfaces.IInstrucaoGravadaDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import liracs.model.domain.InstrucaoGravada;
import liracs.model.domain.Usuario;
import liracs.util.DB.ConnectionManager;
import liracs.util.exceptions.PersistenciaException;

/**
 *
 * @author Nelore
 */
public class InstrucaoGravadaDAO implements IInstrucaoGravadaDAO {

    @Override
    public Long inserir(InstrucaoGravada instrucaoGravada) throws PersistenciaException {

        Long id = null;

        try {
            Connection connection = ConnectionManager.getInstance().getConnection();

            String sql = "INSERT INTO InstrucaoGravada (Cod_Usuario,End_Comando_Voz,Des_Comando) VALUES(?, ?,?) RETURNING Cod_Instrucao";

            PreparedStatement statement = connection.prepareStatement(sql);

            statement.setLong(1, instrucaoGravada.getCod_Usuario());
            statement.setString(2, instrucaoGravada.getEnd_Comando_Voz());
            statement.setString(3, instrucaoGravada.getDesc_Comando_Voz());

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                id = new Long(resultSet.getLong("Cod_Instrucao"));
                instrucaoGravada.setCod_Instrucao(id);
            }

            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
            throw new PersistenciaException(e.getMessage(), e);
        }

        return id;
    }

    @Override
    public void atualizar(InstrucaoGravada instrucaoGravada) throws PersistenciaException {
        try {
            Connection connection = ConnectionManager.getInstance().getConnection();

            String sql = "UPDATE InstrucaoGravada "
                    + " SET End_Comando_Voz = ?, "
                    + "     Des_Comando = ?"
                    + " WHERE Cod_Instrucao = ? AND"
                    + "Cod_Usuario= ?";

            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, instrucaoGravada.getEnd_Comando_Voz());
            statement.setString(2, instrucaoGravada.getDesc_Comando_Voz());
            statement.setLong(3, instrucaoGravada.getCod_Instrucao());
            statement.setLong(4, instrucaoGravada.getCod_Usuario());

            statement.execute();

            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
            throw new PersistenciaException(e.getMessage(), e);
        }
    }

    @Override
    public void excluir(Long codInstrucao, Long codUsuario) throws PersistenciaException {
        try {
            Connection connection = ConnectionManager.getInstance().getConnection();

            String sql = "DELETE FROM InstrucaoGravada WHERE Cod_Instrucao = ? AND Cod_Usuario= ?";

            PreparedStatement statement = connection.prepareStatement(sql);

            statement.setLong(1, codInstrucao);
            statement.setLong(2, codUsuario);

            statement.execute();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
            throw new PersistenciaException(e.getMessage(), e);
        }
    }

    @Override
    public InstrucaoGravada consultarPorId(Long codInstrucao, Long codUsuario) throws PersistenciaException {
        InstrucaoGravada instrucaoGravada = null;
        try {
            Connection connection = ConnectionManager.getInstance().getConnection();

            String sql = "SELECT * FROM InstrucaoGravada WHERE Cod_Instrucao = ? AND Cod_Usuario= ?";

            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setLong(1, codInstrucao);
            statement.setLong(2, codUsuario);

            ResultSet resultSet = statement.executeQuery();
            IUsuarioDAO usuarioDAO = new UsuarioDAO();
            if (resultSet.next()) {
                instrucaoGravada = new InstrucaoGravada();
                Usuario usuario = usuarioDAO.consultarPorId(resultSet.getLong("Cod_Usuario"));
                instrucaoGravada.setUsuario(usuario);
                instrucaoGravada.setCod_Instrucao(resultSet.getLong("Cod_Instrucao"));
                instrucaoGravada.setDesc_Comando_Voz(resultSet.getString("Des_Comando"));
                instrucaoGravada.setEnd_Comando_Voz(resultSet.getString("End_Comando_Voz"));
            }
            connection.close();

        } catch (Exception e) {
            e.printStackTrace();
            throw new PersistenciaException(e.getMessage(), e);
        }
        return instrucaoGravada;
    }

    @Override
    public List<InstrucaoGravada> listarTodos() throws PersistenciaException {

        List<InstrucaoGravada> IGList = new ArrayList<InstrucaoGravada>();

        try {
            Connection connection = ConnectionManager.getInstance().getConnection();

            String sql = "SELECT * FROM InstrucaoGravada";

            PreparedStatement statement = connection.prepareStatement(sql);

            ResultSet resultSet = statement.executeQuery();
            IUsuarioDAO usuarioDAO = new UsuarioDAO();

            while (resultSet.next()) {
                InstrucaoGravada instrucaoGravada = new InstrucaoGravada();
                Usuario usuario = usuarioDAO.consultarPorId(resultSet.getLong("Cod_Usuario"));
                instrucaoGravada.setUsuario(usuario);
                instrucaoGravada.setCod_Instrucao(resultSet.getLong("Cod_Instrucao"));
                instrucaoGravada.setDesc_Comando_Voz(resultSet.getString("Des_Comando"));
                instrucaoGravada.setEnd_Comando_Voz(resultSet.getString("End_Comando_Voz"));

                IGList.add(instrucaoGravada);
            }
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
            throw new PersistenciaException(e.getMessage(), e);
        }
        return IGList;
    }

}
