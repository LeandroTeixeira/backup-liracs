/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sound.execute;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;

/**
 *
 * @author Nelore
 */
public class Interface extends JFrame{
    
    public JButton play;
    public JButton stop;
    
    public Interface() {
      //GridLayout grid = new GridLayout();  
        
      super("teste execucao de audio");
      setSize(400,400);
      setLocation(400,400);
      setLayout(new GridLayout(5,1));
      
      play = new JButton("play");
      stop = new JButton("stop");
      add(play);
      add(stop);
      
      botao handler = new botao();
      
      //eventos
      play.addActionListener(handler);
      stop.addActionListener(handler);
      
    }
    
    
    private class botao implements ActionListener {
        Sound sound = new Sound("/sound.mp3.wav");
        
        @Override
        public void actionPerformed(ActionEvent e) {
            if(e.getSource() == play) {
                sound.play();
            }
            if(e.getSource() == stop) {
                sound.stop();
            }
        }
      
    }
}
