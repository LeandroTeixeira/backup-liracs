/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sound.execute;

import AudioFormatBasis.AudioData;
import AudioFormatBasis.Capt;
import AudioFormatBasis.LoadAudioFromFile;
import AudioFormatBasis.SavingFile;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.AudioFormat;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import sound.gravar.Gravador;
import util.SimulaBD.FileDirectory;

/**
 *
 * @author Nelore
 */
public class Interface extends JFrame{
      
    private JButton play;
    private JButton record;
    private JButton save;
  
    private JPanel p1;
    private JPanel p2;
    private JPanel p3;
    
    //implementação para AUDIOFORMATBASIS
    private File file;
    private AudioData audioData;
    private AudioFormat audioFormat;
    private Capt capture;
    private SavingFile saveAudio;
    
    //Getting AudioInputStream
    private LoadAudioFromFile load;
    private ArrayList<FileDirectory> listEnderecos = new ArrayList<>(); 
    
    private JTextField ler;
    private JButton setAudio;
    
    //Definições de endereco
    FileDirectory fdEndereco;
    private String raiz = "C:\\Users\\Nelore\\Documents\\NetBeansProjects1\\3 ano\\Tcc\\esbocos\\build\\classes\\";
    
    //Gabiarras e testes
    private byte[] array;
    private String endereco;
    
    
    public Interface() {
        
      super("teste execucao de audio");
      setSize(400,400);
      setLocation(400,400);
      setLayout(new GridLayout(5,1));
      
      
      endereco = "/sound.mp3.wav";     //nome do primeiro audio (demo)
      
      p1 = new JPanel();
      p2 = new JPanel();
      p3 = new JPanel();
      
      play = new JButton("Play");
      record = new JButton("record");
      record.setText("Gravar");
      save = new JButton("Save");
      save.setEnabled(false);
      setAudio = new JButton("Set");
      
      ler = new JTextField();
      
      p1.setLayout(new GridLayout(5,5));
      p2.setLayout(new GridLayout(5,5));
      p3.setLayout(new GridLayout(5,5));
      
      p1.add(play);
      p1.add(record);
      
      p2.add(save);
      
      p3.add(ler);
      p3.add(setAudio);
      
      add(p1);
      add(p2);
      add(p3);
      
      
      
      //implementação para AudioFormatBasis (botao record) 
        audioData = new AudioData();
        audioFormat = audioData.getFormat();
        capture = new Capt();
        saveAudio = new SavingFile();
        
        //implementacao para Gettin AudioInputStream
        load = new LoadAudioFromFile();
        
        //implementacao para util.SimulaBD
        fdEndereco = new FileDirectory(raiz, endereco);
        System.out.println(fdEndereco.getFilename());
    
      botao handler = new botao();
      
      
      
      //eventos
      play.addActionListener(handler);
      record.addActionListener(handler);
      save.addActionListener(handler);
      setAudio.addActionListener(handler);
    
    }
    
    
    private class botao implements ActionListener {
        Sound sound = new Sound(fdEndereco.getFilename());
        
        @Override
        public void actionPerformed(ActionEvent e) {
            if(e.getSource() == play) {
                if(play.getText().startsWith("Play")) {
                    sound.play();
                    play.setText("Stop");
                }
                else{
                    sound.stop();
                    play.setText("Play");
                }
            }
            if(e.getSource() == record) {
                if(record.getText().startsWith("Gravar")) {
                    file = null;
                    capture.start();
                    record.setText("Parar");
                }
                else{
                    capture.stop();
                    record.setText("Gravar");
                    if(capture.getResult()==null) {
                        System.out.println("Parece q deu ruim ;-; ");
                    }
                    else{
                        array = capture.getResult();
                        System.out.println("lenght = "+capture.getResult().toString());
                        save.setEnabled(true);
                        endereco = "LIRacsAUD"+UUID.randomUUID().toString()+".wav";
                    }
                    
                }
            }
            if(e.getSource() == save) {
                
                saveAudio.SaveToFile(capture.getAis(),raiz+endereco);
                
                //simula o banco de dados salvando os enderecos dos audios
                listEnderecos.add(new FileDirectory(raiz, endereco));
                load.setListEnderecos(listEnderecos);    //atualiza os enderecos salvos
                
                //atribui o sound com o último áudio
                sound.setClip("/"+endereco);
                
            }
            if(e.getSource() == setAudio) {
                try {
                    sound.setClip("/"+load.loadEndereco(Integer.parseInt(ler.getText()),"filename"));
                } catch (Exception ex) {}
            }
        }
      
    }
}
