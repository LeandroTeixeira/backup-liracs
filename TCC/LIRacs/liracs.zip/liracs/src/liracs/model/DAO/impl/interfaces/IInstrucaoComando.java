/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package liracs.model.DAO.impl.interfaces;

import java.util.List;
import liracs.model.domain.InstrucaoComando;
import liracs.util.exceptions.PersistenciaException;

/**
 *
 * @author Nelore
 */
public interface IInstrucaoComando {
    public Long inserir(InstrucaoComando IC) throws PersistenciaException;
    public void excluir(Long CI,Long CU,Long CC) throws PersistenciaException;
    public InstrucaoComando consultarPorId(Long CI,Long CU,Long CC) throws PersistenciaException;
    public List<InstrucaoComando> listarTodos() throws PersistenciaException;
}
