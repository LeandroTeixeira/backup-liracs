/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AudioFormatBasis;

import java.util.ArrayList;
import util.SimulaBD.FileDirectory;
import org.apache.commons.math3.complex.Complex;
/**
 *
 * @author Nelore
 */
public class Compare {
    
    private ArrayList<FileDirectory> listEnderecos = new ArrayList<>();
    private Capt capture;

    public ArrayList<FileDirectory> getListEnderecos() {
        return listEnderecos;
    }

    public void setListEnderecos(ArrayList<FileDirectory> listEnderecos) {
        this.listEnderecos = listEnderecos;
    }

    public Capt getCapture() {
        return capture;
    }

    public void setCapture(Capt capture) {
        this.capture = capture;
    }
    
    public Compare() {
        this.listEnderecos = null;
        this.capture = null;
    }
    
    public int getCodAudioAproximado() {
        byte audio[] = capture.getByteArrayOutputStream().toByteArray();
        final int size = audio.length;
        int amountPossible = size/ 4096;
        Complex a = new Complex(1);
        
        
        return 0;
    }
    
}
