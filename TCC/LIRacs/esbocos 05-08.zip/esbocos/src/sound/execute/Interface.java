/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sound.execute;

import AudioFormatBasis.AudioData;
import AudioFormatBasis.Capt;
import AudioFormatBasis.SavingFile;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Date;
import java.util.UUID;
import javax.sound.sampled.AudioFormat;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import sound.gravar.Gravador;

/**
 *
 * @author Nelore
 */
public class Interface extends JFrame{
      
    public JButton play;
    public JButton record;
    public JButton save;
  
    public JPanel p1;
    public JPanel p2;
    
    //implementação para AUDIOFORMATBASIS
    private File file;
    private AudioData audioData;
    private AudioFormat audioFormat;
    private Capt capture;
    private SavingFile saveAudio;
    
    //Definições de endereco
    private String raiz = "C:\\Users\\Nelore\\Documents\\NetBeansProjects1\\3 ano\\Tcc\\esbocos\\build\\classes\\";
    
    //Gabiarras e testes
    private byte[] array;
    private String endereco;
    
    
    public Interface() {
        
      super("teste execucao de audio");
      setSize(400,400);
      setLocation(400,400);
      setLayout(new GridLayout(5,1));
      
      endereco = "/sound.mp3.wav";     //AKIIIII FICA O NOME DO AUDIOOO
      
      p1 = new JPanel();
      p2 = new JPanel();
      
      play = new JButton("Play");
      record = new JButton("record");
      record.setText("Gravar");
      save = new JButton("Save");
      save.setEnabled(false);
      
      p1.setLayout(new GridLayout(5,5));
      p2.setLayout(new GridLayout(5,5));
      
      p1.add(play);
      p1.add(record);
      
      p2.add(save);
      
      add(p2);
      add(p1);
      
      
      
      botao handler = new botao();
      
      
      
      //eventos
      play.addActionListener(handler);
      record.addActionListener(handler);
      save.addActionListener(handler);
      
      //implementação para AudioFormatBasis (botao record) 
        audioData = new AudioData();
        audioFormat = audioData.getFormat();
        capture = new Capt();
        saveAudio = new SavingFile();
    }
    
    
    private class botao implements ActionListener {
        Sound sound = new Sound(endereco);
        
        @Override
        public void actionPerformed(ActionEvent e) {
            if(e.getSource() == play) {
                if(play.getText().startsWith("Play")) {
                    sound.play();
                    play.setText("Stop");
                }
                else{
                    sound.stop();
                    play.setText("Play");
                }
            }
            if(e.getSource() == record) {
                if(record.getText().startsWith("Gravar")) {
                    file = null;
                    capture.start();
                    record.setText("Parar");
                }
                else{
                    capture.stop();
                    record.setText("Gravar");
                    if(capture.getResult()==null) {
                        System.out.println("Parece q deu ruim ;-; ");
                    }
                    else{
                        array = capture.getResult();
                        System.out.println("aaaaaaaaaaakatiiiika - lenght = "+capture.getResult().toString());
                        save.setEnabled(true);
                        endereco = "LIRacsAUD"+UUID.randomUUID().toString()+".wav";
                    }
                    
                }
            }
            if(e.getSource() == save) {
                array = capture.getResult();
                saveAudio.SaveToFile(array, capture.getAis(),raiz+endereco);
                sound.setClip("/"+endereco);
            }
        }
      
    }
}
