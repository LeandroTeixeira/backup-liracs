/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package liracs.model.domain;

/**
 *
 * @author Nelore
 */
public class InstrucaoComando {
    private int cod_Instrucao;
    private int cod_Comando;
    private int cod_Usuario;
    private InstrucaoGravada instrucaoGravada;
    private Comando comando;

    public Comando getComando() {
        return comando;
    }

    public void setComando(Comando comando) {
        this.comando = comando;
    }

    public InstrucaoGravada getInstrucaoGravada() {
        return instrucaoGravada;
    }

    public void setInstrucaoGravada(InstrucaoGravada instrucaoGravada) {
        this.instrucaoGravada = instrucaoGravada;
    }
    
    public int getCod_Instrucao() {
        return cod_Instrucao;
    }

    public void setCod_Instrucao(int cod_Instrucao) {
        this.cod_Instrucao = cod_Instrucao;
    }

    public int getCod_Comando() {
        return cod_Comando;
    }

    public void setCod_Comando(int cod_Comando) {
        this.cod_Comando = cod_Comando;
    }

    public int getCod_Usuario() {
        return cod_Usuario;
    }

    public void setCod_Usuario(int cod_Usuario) {
        this.cod_Usuario = cod_Usuario;
    }
    
    
}
