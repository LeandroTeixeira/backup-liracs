/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package liracs.model.DAO.impl.interfaces;

import java.util.List;
import liracs.model.domain.Usuario;
import liracs.util.exceptions.PersistenciaException;

/**
 *
 * @author Nelore
 */
public interface IUsuarioDAO {
    public Long autenticar(String nome, String senha) throws PersistenciaException;
    public Long inserir(Usuario usuario) throws PersistenciaException;
    public void atualizar(Usuario usuario) throws PersistenciaException;
    public void excluir(Long id) throws PersistenciaException;
    public Usuario consultarPorId(Long id) throws PersistenciaException;
    public List<Usuario> listarTodos() throws PersistenciaException;
}
