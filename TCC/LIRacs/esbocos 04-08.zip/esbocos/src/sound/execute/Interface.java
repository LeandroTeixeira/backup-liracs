/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sound.execute;

import AudioFormatBasis.AudioData;
import AudioFormatBasis.Capt;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.sound.sampled.AudioFormat;
import javax.swing.JButton;
import javax.swing.JFrame;
import sound.gravar.Gravador;

/**
 *
 * @author Nelore
 */
public class Interface extends JFrame{
      
    public JButton play;
    public JButton stop;
    public JButton record;
  
    //implementação para AUDIOFORMATBASIS
    private File file;
    private AudioData audioData;
    private AudioFormat audioFormat;
    private Capt capture;
    
    
    
    public Interface() {
        
      super("teste execucao de audio");
      setSize(400,400);
      setLocation(400,400);
      setLayout(new GridLayout(5,1));
      
      play = new JButton("play");
      stop = new JButton("stop");
      record = new JButton("record");
      record.setText("Gravar");
      add(play);
      add(stop);
      add(record);
      
      
      botao handler = new botao();
      
      //eventos
      play.addActionListener(handler);
      stop.addActionListener(handler);
      record.addActionListener(handler);
      
      
      //implementação para AudioFormatBasis (botao record) 
        audioData = new AudioData();
        audioFormat = audioData.getFormat();
        capture = new Capt();
    }
    
    
    private class botao implements ActionListener {
        Sound sound = new Sound("/sound.mp3.wav");
        
        @Override
        public void actionPerformed(ActionEvent e) {
            if(e.getSource() == play) {
                sound.play();
            }
            if(e.getSource() == stop) {
                sound.stop();
            }
            if(e.getSource() == record) {
                if(record.getText().startsWith("Gravar")) {
                    file = null;
                    capture.start();
                    record.setText("Parar");
                }
                else{
                    capture.stop();
                    record.setText("Gravar");
                    if(capture.getResult()==null) {
                        System.out.println("Parece q deu ruim ;-; ");
                    }
                    else{
                        System.out.println("aaaaaaaaaaakatiiiika - lenght = "+capture.getResult().length);
                    }
                    
                }
            }
        }
      
    }
}
