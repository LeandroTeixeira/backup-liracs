/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Liracs.shared.model.domain;

import java.io.File;
import java.io.Serializable;
import java.sql.Blob;

/**
 *
 * @author Nelore
 */
public class Usuario implements Serializable {
    
    private Long codUsuario;
    private String cod_Senha;
    private String nom_Usuario;
    private File endFoto;      //String ?
    
    public Usuario(){}

    public Long getCodUsuario() {
        return codUsuario;
    }

    public void setCodUsuario(Long codUsuario) {
        this.codUsuario = codUsuario;
    }

    public String getCod_Senha() {
        return cod_Senha;
    }

    public void setCod_Senha(String cod_Senha) {
        this.cod_Senha = cod_Senha;
    }

    public String getNom_Usuario() {
        return nom_Usuario;
    }

    public void setNom_Usuario(String nom_Usuario) {
        this.nom_Usuario = nom_Usuario;
    }

    public File getEndFoto() {
        return endFoto;
    }

    public void setEndFoto(File endFoto) {
        this.endFoto = endFoto;
    }
    
    
}
