/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package liracs.model.DAO.impl.interfaces;

import java.util.List;
import liracs.model.domain.Comando;
import liracs.util.exceptions.PersistenciaException;

/**
 *
 * @author Nelore
 */
public interface IComandoDAO {
    public Long inserir(Comando comando) throws PersistenciaException;
    public void excluir(Long id) throws PersistenciaException;
    public Comando consultarPorId(Long id) throws PersistenciaException;
    public List<Comando> listarTodos() throws PersistenciaException;
            
}
