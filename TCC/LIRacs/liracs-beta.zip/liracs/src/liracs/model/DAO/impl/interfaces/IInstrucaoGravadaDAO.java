/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package liracs.model.DAO.impl.interfaces;

import java.util.List;
import liracs.model.domain.InstrucaoGravada;
import liracs.util.exceptions.PersistenciaException;

/**
 *
 * @author Nelore
 */
public interface IInstrucaoGravadaDAO {
    public Long inserir(InstrucaoGravada instrucaoGravada) throws PersistenciaException;
    public void atualizar(InstrucaoGravada instrucaoGravada) throws PersistenciaException;
    public void excluir(Long codInstrucao, Long codUsuario) throws PersistenciaException;
    public InstrucaoGravada consultarPorId(Long codInstrucao, Long codUsuario) throws PersistenciaException;
    public List<InstrucaoGravada> listarTodos() throws PersistenciaException;
}
