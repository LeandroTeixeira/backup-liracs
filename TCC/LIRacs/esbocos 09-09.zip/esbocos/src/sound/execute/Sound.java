/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sound.execute;

import java.applet.Applet;
import java.applet.AudioClip;

/**
 *
 * @author Nelore
 */
public class Sound {
    private AudioClip clip;
    
    public void setClip(String filename) {
        try {
            clip = Applet.newAudioClip(Sound.class.getResource(filename));
        }catch(Exception e){
            e.getStackTrace();
        } 
    }
    
    
    public Sound(String filename) {
        try {
            clip = Applet.newAudioClip(Sound.class.getResource(filename));
        }catch(Exception e){
            e.getStackTrace();
        }
    }
    
    public void play() {
        try{
            new Thread() {
              public void run() {
                clip.play();
              }
            }.start(); 
        }catch(Exception ex) {
            ex.getStackTrace();
        }
    }
    
    public void stop() {
        try{
            new Thread() {
                public void run() {
                  clip.stop();
                }
            }.start();
        }catch(Exception ex1) {
            ex1.getStackTrace();
        }
    }
}
