/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AudioFormatBasis;

import java.io.File;
import java.util.ArrayList;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import util.SimulaBD.FileDirectory;

/**
 *
 * @author Nelore
 */
public class LoadAudioFromFile {
    
    private File file;
    private AudioInputStream audioInputStream;
    private ArrayList<FileDirectory> listEnderecos;

    public void setListEnderecos(ArrayList<FileDirectory> listEnderecos) {
        this.listEnderecos = listEnderecos;
    }
    
    public AudioInputStream getAudioInputStream() {
        return audioInputStream;
    }
    
    public LoadAudioFromFile() {
        listEnderecos = new ArrayList<>();
    }
    
    public AudioInputStream loadFile(int index) throws Exception {
        if(listEnderecos.size() < index) {
            throw new Exception("audio nao encontrado");
        } else {
            file=new File(listEnderecos.get(index).getFullDirectory());
            audioInputStream = AudioSystem.getAudioInputStream(file);
            if(audioInputStream == null) {
                throw new Exception("audio nao encontrado");
            }
            else {
                return audioInputStream;
            }
        }
    }
    
    public String loadEndereco(int index, String model) throws Exception {
        if(listEnderecos.size() < index) {
            throw new Exception("deu ruim lek");
        }else {
            if(model.startsWith("raiz")) {
                return listEnderecos.get(index).getRaiz();
            }
            if(model.startsWith("filename")) {
                return listEnderecos.get(index).getFilename();
            }
            else {
                throw new Exception("erro de procura inesperada");
            }
        }
    }
}
